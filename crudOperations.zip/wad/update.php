<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
</head>
<body>

	<?php
		$conn = new mysqli("localhost","root","","wad");
		$selectData = "select * from std_info where stdId=".$_GET['id'];
		$ds = $conn->query($selectData);
		$row = $ds->fetch_assoc();
	?>
		<form method="POST" action="updateData.php">
		<input type="text" name="stdName" value="<?php echo $row['stdName']; ?>">

		<input type="text" name="stdEmail" value="<?php echo $row['stdEmail']; ?>">

		<input type="text" name="stdAge" value="<?php echo $row['stdAge']; ?>">

		<input type="submit" value="Submit My Data">
	</form>
</body>
</html>