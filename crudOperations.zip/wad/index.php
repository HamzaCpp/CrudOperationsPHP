<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
</head>
<body>
	<form method="POST" action="insertData.php">
		<input type="text" name="stdName" placeholder="Enter Student Name">

		<input type="text" name="stdEmail" placeholder="Enter Student Email">

		<input type="text" name="stdAge" placeholder="Enter Student Age">

		<input type="submit" value="Submit My Data">
	</form>

<?php

$conn = new mysqli("localhost","root","","wad");
$selectData = "select * from std_info";
$ds = $conn->query($selectData);
echo"<table border='1'>";
echo "<tr>";
		echo"<th>";
		echo "ID";
	echo"</th>";
	echo"<th>";
		echo "Name";
	echo"</th>";

		echo"<th>";
		echo "Email";
	echo"</th>";

		echo"<th>";
		echo "Age";
	echo"</th>";
echo "</tr>";

while($row = $ds->fetch_assoc()) {
	echo "<tr>";
		echo"<td>";
			echo $row["stdId"];
		echo"</td>";
		echo"<td>";
			echo $row["stdName"];
		echo"</td>";

			echo"<td>";
			echo $row["stdEmail"];
		echo"</td>";

			echo"<td>";
			echo $row["stdAge"];
		echo"</td>";

		echo"<td>";
			echo "<a href='delete.php?id=".$row["stdId"]."'>Delete</a>";
		echo"</td>";

		echo"<td>";
			echo "<a href='update.php?id=".$row["stdId"]."'>Update</a>";
		echo"</td>";
	
	echo"</tr>";
}

echo"</table>";

?>
</body>
</html>