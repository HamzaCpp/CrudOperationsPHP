<?php


$id = $_GET['id'];

$conn = new mysqli("localhost","root","","wad");
$q = "delete from std_info where stdId =".$id;
if($conn->query($q)==true){
	header("Location:index.php");
}else{
	echo $conn->error;
}

?>