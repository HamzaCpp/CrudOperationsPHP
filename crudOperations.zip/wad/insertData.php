<?php


$name = $_POST['stdName'];
$email = $_POST['stdEmail'];
$age = $_POST['stdAge'];

// echo "Name is ".$name."</br>";
// echo "Email is ".$email."</br>";
// echo "Age is ".$age."</br>";

$conn = new mysqli("localhost","root","","wad");
$q = "insert into std_info(stdName,stdEmail,stdAge)values('".$name."','".$email."',".$age.")";
if($conn->query($q)==true){
	//header("Location:index.php");
}else{
	echo $conn->error;
}

?>